// Create a loop that rotates 500 times using the for loop where you just pull out the numbers divisible by 3 and 4

for( let i = 1; i <= 500; i++){
    if( i % 3 == 0 ){
        console.log(i)
    }

    
}