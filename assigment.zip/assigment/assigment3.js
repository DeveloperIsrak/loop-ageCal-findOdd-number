// Find the number divisible by 7 between 1 and 1000

for( let i = 1; i <= 1000; i++){
    if( i % 7 == 0 ){
        console.log(i)
    }

    
}