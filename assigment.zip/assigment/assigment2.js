//Find the even and odd numbers from 1 and 1000 through for loop

for( let i = 1; i <= 1000; i++){
    if( i % 2 == 0 ){
        console.log(i)
    }

    
}