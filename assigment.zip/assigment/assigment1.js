//Create a loop that will rotate from 1000 to 300


for( let i = 1000; i >= 700; i--){
    console.log(i);
}